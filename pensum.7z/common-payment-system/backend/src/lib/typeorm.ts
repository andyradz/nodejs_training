import { getConnectionOptions, createConnection, Connection } from "typeorm";


//https://docs.nestjs.com/techniques/database

export const createTypeormConn = async (): Promise<Connection> => {
    const connectionOptions = await getConnectionOptions(process.env.NODE_ENV);
    return createConnection({ ...connectionOptions, name: "default" });
};