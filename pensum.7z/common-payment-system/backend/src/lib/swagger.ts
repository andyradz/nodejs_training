import * as express from "express";

import swaggerUi = require('swagger-ui-express');
import swaggerDocument = require('../../swagger.json');

export class Swagger {

    public static config(app: express.Application): void {
        new Swagger(app);
    }

    private constructor(app: express.Application) {              
        app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
    }
}