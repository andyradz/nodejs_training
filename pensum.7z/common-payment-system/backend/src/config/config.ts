export default {
    jwtSecret: "@QEGTUI"
};
