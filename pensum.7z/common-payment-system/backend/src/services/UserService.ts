import { User } from "../entities/User";
import { validate } from "class-validator";
import { getRepository } from "typeorm";
import { IUserService } from "./IUserService";

export class UserService implements IUserService {

    /**
     * 
     * @param username 
     * @param password 
     */
    public async create(username: string, password: string): Promise<User | Record<string, string>> {
        //Get parameters from the body
        let user = new User();
        user.username = username;
        user.password = password;

        //Validade if the parameters are ok
        const errors = await validate(user);
        if (errors.length > 0) {
            return Promise.reject({ name: 'UserNotValid', message: 'parameter not valid' });
        }

        //Hash the password, to securely store on DB
        user.hashPassword();

        //Try to save. If fails, the username is already in use
        const userRepository = getRepository(User);
        try {
            await userRepository.save(user);
        } catch (e) {
            return Promise.reject({ name: 'UsernameExist', message: 'username already exist' });
        }

        //If all ok, send 201 response
        return Promise.resolve(user);
    }

    /**
     * 
     * @param userId 
     */
    public async select(userId: number): Promise<User | Record<string, string>> {

        if (userId <= 0 || Number.isNaN(userId))
            return Promise.reject({ name: 'UserNotValid', message: 'parameter id not valid' });

        const user = new User();
        user.username = "andrzej";
        user.password = "password";
        
        if (!user)
            return Promise.reject({ name: 'UserNotFound', message: 'user not exists in database' });


        return Promise.resolve(user);
    }
}