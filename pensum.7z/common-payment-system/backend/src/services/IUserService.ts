import { User } from "../entities/User";

/**
 * 
 * @version 1.0.0.0
 * @copyright codigo digital technology
 * @since 2021
 */

export interface IUserService {

    /**
     * 
     * @param username 
     * @param password 
     */
    create(username: string, password: string): Promise<User | Record<string, string>>;

    /**
     * @
     * @param userId 
     */
    select(userId: number): Promise<User | Record<string, string>>;
}