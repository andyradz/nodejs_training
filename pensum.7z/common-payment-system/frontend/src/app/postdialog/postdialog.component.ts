import { Component, OnInit, EventEmitter, Inject, ViewChild, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PostService } from '../services/post.service';

@Component({
	selector: 'app-postdialog',
	templateUrl: './postdialog.component.html',
	styleUrls: ['./postdialog.component.css']
})
export class PostdialogComponent implements OnInit {

	constructor(
		public dialogRef: MatDialogRef<PostdialogComponent>,
		@Inject(MAT_DIALOG_DATA) public data: any,
		public dataService: PostService
	) {
	}
	blogPost = {
		title: '',
		number: '',
		body: '',
		category: '',
		position: 0,
		percentage: 0,
		date_posted: new Date()
	};
	public event: EventEmitter<any> = new EventEmitter();
	categories = this.dataService.getCategories();

	ngOnInit(): void {
		// this.form = new FormGroup({
		// 	name: new FormGroup({
		// 	}),
		// });
	}

	public onNoClick(): void {
		this.dialogRef.close();
	}

	onSubmit(): void {
		this.blogPost.position = this.dataService.dataLength();
		this.event.emit({ data: this.blogPost });
		this.dialogRef.close();
	}

	public onReset(): void {
		//form.reset();
	}
}
