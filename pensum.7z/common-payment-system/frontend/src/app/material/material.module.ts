import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatMenuModule } from '@angular/material/menu';
import { MatTabsModule } from '@angular/material/tabs';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatPaginatorModule } from '@angular/material/paginator'
import {MatSort, MatSortModule} from '@angular/material/sort';
import {ScrollingModule} from '@angular/cdk/scrolling';
import { MatOptionModule } from '@angular/material/core';
@NgModule({
	declarations: [],
	imports: [
		CommonModule,
		MatSidenavModule,
		MatToolbarModule,
		MatIconModule,
		MatListModule,
		MatButtonModule,
		MatTableModule,
		MatCardModule,
		MatDialogModule,
		MatSelectModule,
		MatInputModule,
		MatCheckboxModule,
		MatMenuModule,
		MatTabsModule,
		MatSnackBarModule,
		MatTooltipModule,
		MatProgressSpinnerModule,
		MatPaginatorModule,
		MatSortModule,
		ScrollingModule,
		MatOptionModule		
	],
	exports: [
		MatSidenavModule,
		MatToolbarModule,
		MatIconModule,
		MatListModule,
		MatButtonModule,
		MatTableModule,
		MatCardModule,
		MatDialogModule,
		MatSelectModule,
		MatInputModule,
		MatCheckboxModule,
		MatMenuModule,
		MatTabsModule,
		MatSnackBarModule,
		MatTooltipModule,
		MatProgressSpinnerModule,
		MatPaginatorModule,
		MatSort,
		ScrollingModule,
		MatOptionModule
	]
})
export class MaterialModule { }
