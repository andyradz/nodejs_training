import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Pensum.ManagmentComponent } from './pensum.managment.component';

describe('Pensum.ManagmentComponent', () => {
  let component: Pensum.ManagmentComponent;
  let fixture: ComponentFixture<Pensum.ManagmentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Pensum.ManagmentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Pensum.ManagmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
