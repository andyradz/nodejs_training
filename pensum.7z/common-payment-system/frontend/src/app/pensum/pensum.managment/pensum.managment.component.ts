import { Component, OnInit } from '@angular/core';
import { Observable, fromEvent, of, from } from 'rxjs';
import { DataSource } from '@angular/cdk/table';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ViewChild } from '@angular/core';
import { AfterViewInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { AfterContentInit } from '@angular/core';
import { ReplacementService } from 'src/app/services/replacement.service';
import { IReplacement, IReplacmentQuery } from 'src/app/data/IReplacement';
import { tap } from 'rxjs/operators';
import { PaginatedDataSource } from 'src/app/components/dashboard/paginated-datasource';
import { User } from 'src/app/core/models/User';

//https://medium.com/angular-in-depth/angular-material-pagination-datasource-73080d3457fe

@Component({
  selector: 'app-pensum.managment',
  templateUrl: './pensum.managment.component.html',
  styleUrls: ['./pensum.managment.component.css']
})
export class PensumManagmentComponent implements OnInit, AfterContentInit {

  isExpanded = false;
  selected = 'option2';

  displayedColumns: string[] = [
    'checked',
    'id',
    'dateReplacement',
    'personReplacment',
    'roomReplacement',
    'lessonHour',
    'roomNumber'];
  //dataSource = new MatTableDataSource<PensumItem>(this.ELEMENT_DATA);
  //dataSource = new PensumDataSource(this.replacementService).connect();
  //datasource = new PaginatedDataSource<IReplacement, >(
  //request => this.replacementService.page(request),
  // {property: 'username', order: 'desc'}

  dataSource = new PaginatedDataSource<IReplacement, IReplacmentQuery>(
    (request, query) => this.replacementService.page(request, query),
    { property: 'id', order: 'desc' },
    { search: '', lessonPerson: undefined, lessonDate: undefined });

  @ViewChild(MatSort, { static: true }) sort: MatSort;
  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;

  filterValues = {};
  filterSelectObj = [];

  constructor(private replacementService: ReplacementService) {

    this.filterSelectObj = [{
      name: 'Numer porządkowy',
      columnProp: 'id',
      options: []
    },
    {
      name: 'Data zastępstwa',
      columnProp: 'dateReplacment',
      options: []
    },
    {
      name: 'Osoba zastępowana',
      columnProp: 'personReplacment',
      options: []
    },
    {
      name: 'Zastępstwo w klasie',
      columnProp: 'roomReplacement',
      options: []
    },
    {
      name: 'Godzina lekcyjna',
      columnProp: 'lessonHour',
      options: []
    },
    {
      name: 'Numer sali',
      columnProp: 'roomNumber',
      options: []
    },
    ]
  }

  ngOnInit(): void {

    // this.replacementService.loadReplacements()
    //   .subscribe(product => {          
    //       console.log(this.dataSource);
    //     }
    //   );

    // this.dataSource.pipe(
    //   tap(item => console.log(item))
    // )
    //this.dataSource.paginator = this.paginator;
    //this.dataSource.sort = this.sort;    
  }

  ngAfterContentInit() {
    this.filterSelectObj.filter((o) => {
      //o.options = this.getFilterObject(this.ELEMENT_DATA, o.columnProp);
    });
    //this.dataSource.filterPredicate = this.createFilter();
    //this.dataSource.filterPredicate = (data: PensumItem, filter: string) => !filter || data['id'] === filter;
  }

  public applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    //this.dataSource.filter = filterValue;
  }

  // Called on Filter change
  public filterChange(filter, event) {
    let filterValues = {}
    //this.filterValues[filter.columnProp] = event.target.value.trim().toLowerCase()
    this.filterValues[filter.columnProp] = event.value;
    //this.dataSource.filter = JSON.stringify(this.filterValues)
  }

  // Custom filter method fot Angular Material Datatable
  public createFilter() {

    const filterFunction = function (data: any, filter: string): boolean {

      let searchTerms: any[] = JSON.parse(filter);
      let isFilterSet = false;

      for (const col in searchTerms) {
        if (searchTerms[col].toString() !== '') {
          isFilterSet = true;
        } else {
          delete searchTerms[col];
        }
      }

      console.log(searchTerms);

      const nameSearch = () => {
        let found = false;
        if (isFilterSet) {
          for (const col in searchTerms) {
            //searchTerms[col].trim().toLowerCase().split(' ').forEach(word => {
            //searchTerms[col].forEach(word => {
            //if (data[col].toString().toLowerCase().indexOf(word) != -1 && isFilterSet) {
            found = true
            //}
            //});
          }
          return found
        } else {
          return true;
        }
      }
      return nameSearch()
    }
    return filterFunction
  }

  public getFilterObject(fullObj, key) {
    const uniqChk = [];
    fullObj.filter((obj) => {
      if (!uniqChk.includes(obj[key])) {
        uniqChk.push(obj[key]);
      }
      return obj;
    });
    return uniqChk;
  }

  // Reset table filters
  public resetFilters(): void {

    this.filterValues = {}
    this.filterSelectObj.forEach((value, key) => {
      value.modelValue = undefined;
    })
    //this.dataSource.filter = "";
  }
}

export class PensumDataSource extends DataSource<any> {

  constructor(private replacementService: ReplacementService) {
    super();
  }

  connect(): Observable<IReplacement[]> {

    return this.replacementService.loadReplacements();
  }

  disconnect() {
  }
}
