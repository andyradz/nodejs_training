import { AnnoyingPopupDirectiveDirective } from './annoying-popup-directive.directive';

describe('AnnoyingPopupDirectiveDirective', () => {
  it('should create an instance', () => {
    //const directive = new AnnoyingPopupDirectiveDirective();
    //expect(directive).toBeTruthy();
  });
});
