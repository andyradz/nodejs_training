import { Directive, Input, OnInit, TemplateRef, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[popup]'
})
export class AnnoyingPopupDirectiveDirective implements OnInit {

  @Input() timeout = 2000;
  @Input() color = 'pink';

  constructor(private viewContainerRef: ViewContainerRef,
    private templateRef: TemplateRef<any>) { }

  ngOnInit() {
    setTimeout(() => {
      const embeddedView = this.viewContainerRef.createEmbeddedView(this.templateRef);
      embeddedView.rootNodes[0].style['background-color'] = this.color;
    }, this.timeout);
  }
}