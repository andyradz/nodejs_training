import { RequestCache } from './request-cache';

describe('RequestCache', () => {
  it('should create an instance', () => {
    expect(new RequestCache()).toBeTruthy();
  });
});
