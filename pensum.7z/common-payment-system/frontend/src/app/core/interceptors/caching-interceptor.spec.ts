import { CachingInterceptor } from './caching-interceptor';

describe('CachingInterceptor', () => {
  it('should create an instance', () => {
    expect(new CachingInterceptor()).toBeTruthy();
  });
});
