import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AnnoyingPopupDirectiveDirective } from './directive/annoying-popup-directive.directive';



@NgModule({
  declarations: [AnnoyingPopupDirectiveDirective],
  imports: [
    CommonModule
  ],
  exports: [AnnoyingPopupDirectiveDirective]
})
export class CoreModule { }
