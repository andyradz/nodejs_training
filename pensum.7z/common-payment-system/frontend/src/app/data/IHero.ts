import { Guid } from "guid-typescript";

export interface IHero {
    id: number;
    checked: boolean;
    title: string;
    category: string;
    date_posted: Date;
    position: number;
    body: string;
    amount: number,
    highlighted?: boolean;
    hovered?: boolean;
}