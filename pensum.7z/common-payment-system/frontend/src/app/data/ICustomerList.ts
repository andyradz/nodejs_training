export interface ICustomerList {
  id: number;
  email: string;
  userName: string;
  name: string;
  CustomerRole: string;
  Companyname: string;
  Active: boolean;
  Createdon: Date;
  Lastactivity: Date;
}
