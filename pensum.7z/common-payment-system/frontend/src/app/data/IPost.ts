import { Guid } from "guid-typescript";

export interface IPost {
    id: Guid;
    checked: boolean;
    title: string;
    category: string;
    date_posted: Date;
    position: number;
    body: string;
    percentage: number,
    amount: number,
    highlighted?: boolean;
    hovered?: boolean;
}

export interface IPostQuery {
    search: string;
    registration: Date;
  }
