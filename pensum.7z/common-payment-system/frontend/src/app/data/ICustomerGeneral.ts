import { never } from 'rxjs';

export interface ICusomerGeneral {
    index?: number;
    oper(name: string, surname: string): boolean;
}

export enum CustomerGnder {
    Male,
    Female
}

declare type Logical = "True" | "False" | "Y" | "N" | "T" | "N" | "0" | "1" ;

type Easing = "ease-in" | "ease-out" | "ease-in-out";

type GenderStrings = keyof typeof CustomerGnder;

let a = CustomerGnder.Male;

let custG = {} as ICusomerGeneral;
custG.index = 10;
custG.oper = (n, s) => n.length === s.length;

let custC: ICusomerGeneral = {
    index: 1,
    oper: (n, s) => n.length === s.length
};

const array: Array<number> = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 5e4];

let tuple: [number, string][];
tuple[0] = [1, "10"];
tuple[1] = [1, "10"];

function neverOccur(value: string | number): any {
    if (typeof value !== "string")
        return value;

    if (typeof value !== "number")
        return value;

    return never;        
}

function add(a: number = 0, b?: number, ...args: string[]): number {
    tuple.forEach(element => {

    });
    if (b)
        return a + b;
    return a + 1;
}
//anoanymu function
let func = function (a: number, b: number): number {
    return 0;
}

let myAdd: (x: number, y: number) => number = (x: number,
    y: number): number => x + y;