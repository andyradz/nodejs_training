/**
 * Struktura danych obiektu zastępstwa
 */
export interface IReplacement {

    /**
     * Unikalny identyfikator encji
     */
    id: number;

    /**
     * Data zastępstwa 
     */
    lessonDate: Date;

    /**
     * Godzina zastępstwa 
     */
    lessonHour: IReplacementHour;
    
    /**
     * Osoba zastępowana
     */
    lessonPerson: string;

    /**
     * Numer klasy
     */
    lessonClassNo: string;

    /**
     * Numer sali
     */
    lessonRoomNo: number;    
}

export interface IReplacementHour{

    /**
     * Godzina początku lekcji zastępstwa
     */
    lessonTimeStart: Date;

    /**
     * Godzina końca lekcji zastępstwa
     */
    lessonTimeEnd: Date;
}

export interface IReplacmentQuery {
    search: string;
    lessonDate: Date;
    lessonPerson: string;
  }