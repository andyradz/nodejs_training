import * as moment from 'moment';
import { Moment } from 'moment';
import { Observable, timer, AsyncSubject } from 'rxjs';
import { Subject, ReplaySubject, Subscription } from 'rxjs';
import { UniqueSelectionDispatcher } from '@angular/cdk/collections';

export interface IDisposable {
    dispose(): void;
}

export function using<T extends IDisposable>(resource: T, func: (resource: T) => void) {
    try {
        func(resource);
    } finally {
        resource.dispose();
    }
}

export class CountdownCalc implements IDisposable {

    static readonly clockInterval: number = 1_000.0;

    private secondInterval$: Observable<number>;
    private countdownData$: Subject<CountdownItem>;
    private subscription: Subscription;
    private nums: number;

    public constructor(private elapsTime: number) {
        this.countdownData$ = new Subject<CountdownItem>();
        this.secondInterval$ = timer(0, CountdownCalc.clockInterval);
        this.subscription = this.secondInterval$.subscribe((seconds) => this.calc(seconds));
    }

    public dispose = (): void => {
        this.subscription.unsubscribe();
        this.countdownData$.complete();
    }

    private calc = (seconds: number): void => {
        this.nums = this.elapsTime - seconds;
        this.countdownData$.next(new CountdownItem(this.elapsTime, this.nums));
    }

    public get Stream(): Observable<CountdownItem> {
        return this.countdownData$.asObservable();
    }
}


export class CountdownItem {

    private searchEndDate: moment.Moment;
    private searchDate: Moment = moment();
    private days: number;
    private hours: number;
    private minutes: number;
    private seconds: number;
    private remainingTime: number;
    private oneQuarter: number;
    private halfOfTime: number;
    private threeQuarters: number;

    public constructor(private elapsTime: number, private secondsInterval: number) {

        this.searchEndDate = this.searchDate.add(this.secondsInterval, 'seconds');
        this.halfOfTime = (this.searchEndDate.diff(moment()) / CountdownCalc.clockInterval) * .5;
        this.oneQuarter = (this.searchEndDate.diff(moment()) / CountdownCalc.clockInterval) * .25;
        this.threeQuarters = (this.searchEndDate.diff(moment()) / CountdownCalc.clockInterval) * .75;

        this.calculate();
    }

    private calculate = (): void => {

        const currentTime: moment.Moment = moment();
        let temp: number = 0;
        this.remainingTime = this.searchEndDate.diff(currentTime);
        this.remainingTime = this.remainingTime / 1000;
        temp = this.remainingTime;

        if (this.remainingTime <= 0) {
            this.searchDate = moment();
            this.searchEndDate = this.searchDate.add(this.elapsTime, 'seconds');
        } else {
            this.days = Math.floor(temp / 86400.);
            temp -= this.days * 86400.;
            this.hours = Math.floor(temp / 3600.);
            temp -= this.hours * 3600.;
            this.minutes = Math.floor(temp / 60.);
            temp -= this.minutes * 60.;
            this.seconds = Math.floor(temp);
        }
    }

    public get IsOneQuarter(): boolean {
        return (this.RemainingTime <= this.OneQuarter);
    }

    public get IsHalfQuarter(): boolean {
        return (this.RemainingTime <= this.HalfOfTime);
    }

    public get IsThreefQuarter(): boolean {
        return (this.RemainingTime <= this.ThreeQuarters);
    }

    public get OneQuarter(): number {
        return this.oneQuarter;
    }

    public get HalfOfTime(): number {
        return this.halfOfTime;
    }

    private get ThreeQuarters(): number {
        return this.threeQuarters
    }

    public get RemainingTime(): number {
        return this.secondsInterval;
    }
    public get Days(): number {
        return this.days;
    }

    public get Hours(): number {
        return this.hours;
    }

    public get Minutes(): number {
        return this.minutes;
    }

    public get Seconds(): number {
        return this.seconds;
    }
}