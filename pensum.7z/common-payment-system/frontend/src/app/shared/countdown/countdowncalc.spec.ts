import { CountdownCalc, CountdownItem, using } from './countdowncalc';

describe('Countdowncalc', () => {
  it('should create an instance', () => {
    expect(new CountdownCalc(3_600))
      .toBeTruthy();

    using(new CountdownCalc(3_600), 
         () => { console.log('czyszczenie danych obiektu') });
  });
});
