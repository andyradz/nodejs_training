import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef, HostListener, OnDestroy, ChangeDetectionStrategy } from '@angular/core';
import { Subscription, Observable, timer } from 'rxjs';
import * as moment from 'moment';
import { Moment } from 'moment';
import { Event } from '@angular/router';
import { CountdownCalc, CountdownItem } from '../../countdown/countdowncalc';

// https://codepen.io/shshaw/pen/BzObXp

// https://dzone.com/articles/angular-timer-auto-refresh-component
@Component({
	selector: 'app-countdown',
	templateUrl: './countdown.component.html',
	styleUrls: ['./countdown.component.css']
	//changeDetection: ChangeDetectionStrategy.OnPush
})
export class CountdownComponent implements OnInit, OnDestroy {

	static readonly clockInterval: number = 1_000;

	@Output() TimerExpired: EventEmitter<any> = new EventEmitter<any>();
	@Input() SearchDate: Moment = moment();
	@Input() ElapsTime: number;
	countdownItem: CountdownItem;

	secondInterval$: Observable<number>;
	stream$: Observable<CountdownItem>;

	constructor(private ref: ChangeDetectorRef) {
		this.secondInterval$ = timer(0, CountdownComponent.clockInterval);
	}

	ngOnInit(): void {
		this.stream$ = new CountdownCalc(this.ElapsTime).Stream;
		this.countdownItem = new CountdownItem(this.ElapsTime, this.ElapsTime);
		this.stream$.subscribe((item: CountdownItem) => this.getItem(item));
	}

	private getItem(item: CountdownItem): void {
		this.countdownItem = item;
	}

	public textClass(): string {

		if (this.countdownItem.IsOneQuarter)
			return 'strings-red';

		else if (this.countdownItem.IsHalfQuarter)
			return 'strings-orange';

		else if (this.countdownItem.IsThreefQuarter)
			return 'strings-yellow';

		else
			return 'strings';

		//'strings-red timeRefHours' : 'strings timeRefHours';
	}

	@HostListener('window:unload', ['$event'])
	ngOnDestroy(): void {
	}

	@HostListener('window:keydown', ['$event'])
	handleKeyboardEvent(event: KeyboardEvent) {

		console.log(event);
	}

	//SYMULOWANIE NACIŚNIECIA PRZYCISKU MYSZKI
	// it('mousedown on the div', inject([MyService], service) => {
	// 	debugEle[0].triggerEventHandler('mousedown',{pageX:50, pageY: 40});
	// 	debugEle[0].triggerEventHandler('mousemove',{pageX:60, pageY: 50});
	// 	// assuming you are calculating the difference between the second and first objects.
	// 	expect(service.someObj).toBe({x:10, y:10});
	//const btn = btnDbg ? <HTMLButtonElement>btnDbg.nativeElement : new HTMLButtonElement();
	//btn.dispatchEvent(new Event('mousedown'));
	// });

	// @HostListener('mouseover', ['$event'])
	// @HostListener('mouseenter', ['$event'])
	// @HostListener('mouseout', ['$event'])
	// @HostListener('mousedown', ['$event'])
	handleMouseEvent(event: MouseEvent) {

		console.log(event);
	}

	refresh(): void {
	}

	get isHidden(): boolean {
		return false;
		// return Math.round(this.countdownItem.RemainingTime) == 0;
	}
}
