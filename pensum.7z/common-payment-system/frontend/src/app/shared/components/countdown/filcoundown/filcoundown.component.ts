import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filcoundown',
  templateUrl: './filcoundown.component.html',
  styleUrls: ['./filcoundown.component.css']
})
export class FilcoundownComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
