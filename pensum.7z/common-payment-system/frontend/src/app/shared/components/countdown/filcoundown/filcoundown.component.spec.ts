import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FilcoundownComponent } from './filcoundown.component';

describe('FilcoundownComponent', () => {
  let component: FilcoundownComponent;
  let fixture: ComponentFixture<FilcoundownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FilcoundownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FilcoundownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
