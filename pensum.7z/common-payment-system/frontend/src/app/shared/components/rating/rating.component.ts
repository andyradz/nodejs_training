import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ViewEncapsulation } from '@angular/compiler/src/core';

@Component({
	selector: 'app-rating',
	templateUrl: './rating.component.html',
	styleUrls: ['./rating.component.css']
	//encapsulation: ViewEncapsulation.Native
})
export class RatingComponent implements OnInit {

	@Input('rating') rating = 0;
	@Input('starCount') starCount = 6;
	@Input('color') color = '#f58b00';
	@Output() ratingUpdated = new EventEmitter();

	snackBarDuration = 1000;
	ratingArray = [];

	//#region "constructors"

	constructor(private snackBar: MatSnackBar) {
	}

	//#endregion

	ngOnInit(): void {

		for (let index = 0; index < this.starCount; index++) {
			this.ratingArray.push(index);
		}
	}

	//#region "events"

	onClick(rating: number): boolean {

		this.snackBar
			.open(`You rated ${rating} / ${this.starCount}`, '', {
				duration: this.snackBarDuration
			});
		this.ratingUpdated.emit(rating);

		return false;
	}

	//#endregion

	//#region "procedures"

	/**
    * Pokazuje właściwoą ikonę dla wartości ratingu
	*
    * @param index numer indeksu bieżacej gwiazdki ratingu
    * @returns Nazwę ikony z angular material icons
    */
	showIcon(index: number): string {

		const starValue = index + 1;

		if (starValue <= Math.floor(this.rating)) {
			return 'star';
		} else if (starValue == Math.round(this.rating)) {
			return 'star_half_icon';
		} else {
			return 'star_border';
		}
	}

	async delay(timeout: number) {
		await new Promise(resolve => setTimeout(() => resolve(), timeout));
	}

	//#endregion
}
