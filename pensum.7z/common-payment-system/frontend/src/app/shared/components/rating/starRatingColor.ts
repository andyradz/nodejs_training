export enum StarRatingColor {
    primary = 'primary',
    accent = 'accent',
    warn = 'warn'
}
