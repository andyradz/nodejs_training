import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssetsTypePipe } from './pipes/assets-type.pipe';
import { RatingComponent } from './components/rating/rating.component';
import { CountdownComponent } from './components/countdown/countdown.component';
import { FilcoundownComponent } from './components/countdown/filcoundown/filcoundown.component';
import { SanitizeHtmlPipe } from './pipes/sanitize-html.pipe';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';



@NgModule({
  declarations: [
    AssetsTypePipe,
    RatingComponent,
    CountdownComponent,
    FilcoundownComponent,
    SanitizeHtmlPipe,
    ConfirmDialogComponent],
  imports: [
    CommonModule
  ]
})
export class SharedModule { }
