import { SanitizeHtmlPipe } from './sanitize-html.pipe';
import { ɵDomSanitizerImpl } from '@angular/platform-browser';

describe('SanitizeHtmlPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SanitizeHtmlPipe(this.call(this.keepHtml("[innerHTML] = htmlSnippet")));
    expect(pipe).toBeTruthy();
  });

//   fixture.debugElement.query(By.css('.reset-button'))
//   .triggerEventHandler('click', {});
// fixture.detectChanges();
// expect(fixture.debugElement.query(By.css('#error-msg'))).toBe(null);
// expect(fixture.componentInstance.isValid()).toBe(false)
// TestBed.configureTestingModule({
//   declarations: [ MyDynamicComponent ],
// }).overrideModule(BrowserDynamicTestingModule, {
//   set: {
//     entryComponents: [ MyDynamicComponent ],
//   }
// });

// beforeEach(() => TestBed.configureTestingModule({
//   declarations: [MyComponent],
//   imports: [],
//   providers: [MyService],
//   schemas: [NO_ERRORS_SCHEMA]
// }));
});
// beforeEach(() => {
//   TestBed.configureTestingModule({
//     declarations: [SomeComponentUsingPipe, PipeIWantToMock],
//   });
//   spyOn(PipeIWantToMock.prototype,                    'transform').and.returnValue('myValue');
// });

export const keepHtml = (value: string) =>{
  const sanitizer = new ɵDomSanitizerImpl(document);
  return sanitizer.bypassSecurityTrustHtml('Html');
}