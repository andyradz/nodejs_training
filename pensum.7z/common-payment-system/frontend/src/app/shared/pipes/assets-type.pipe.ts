import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'assetsType'
})
export class AssetsTypePipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {

    let result = '';
    switch (value) {
      case 'NONE': {
        result = 'Brak';
        break;
      }

      case 'CASH': {
        result = 'Środki pieniężne';
        break;
      }

      case 'FINS': {
        result = 'Instrumenty finansowe';
        break;
      }
      default:
        result = 'Brak';
        break;
    }
    return result;
  }

}
