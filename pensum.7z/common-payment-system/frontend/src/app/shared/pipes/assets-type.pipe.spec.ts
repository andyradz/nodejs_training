import { AssetsTypePipe } from './assets-type.pipe';

describe('AssetsTypePipe', () => {
  let pipe = new AssetsTypePipe();

  beforeEach(() => {
    pipe = new AssetsTypePipe();
  });

  it('create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('sholud be assets type NONE', () => {
    expect(pipe.transform('NONE', [])).toBe('Brak');
  });

  it('should be assets type CASH', () => {
    expect(pipe.transform('CASH', [])).toBe('Środki pieniężne');
  });

  it('should be assets type FINS', () => {
    expect(pipe.transform('FINS', [])).toBe('Instrumenty finansowe');
  });

  it('should be assets type empty', () => {
    expect(pipe.transform('', [])).toBe('Brak');
  });
});
