import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { CustomerManagmentComponent } from './customers/customer-managment/customer-managment.component';
import { PensumManagmentComponent } from './pensum/pensum.managment/pensum.managment.component';

const routes: Routes = [
	{ path: '', component: WelcomeComponent },
	{ path: 'dashboard', component: DashboardComponent },
	{ path: 'login', component: LoginComponent },
	{ path: 'customers', component: CustomerManagmentComponent },
	{ path: 'pensum', component: PensumManagmentComponent },
	{
		path: 'welcome',
		children: [
			{ path: '', component: WelcomeComponent },
			{ path: ':id', component: WelcomeComponent }
		]
	},
];

@NgModule({
	imports: [RouterModule.forRoot(routes, {
		enableTracing: true,
		scrollPositionRestoration: 'enabled'
	})],
	exports: [RouterModule]
})
export class AppRoutingModule { }
