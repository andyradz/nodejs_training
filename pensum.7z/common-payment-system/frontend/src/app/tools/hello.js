"use strict";
// var Observable = require('rxjs/Observable').Observable;
// // // patch Observable with appropriate methods
//  require('rxjs/add/observable/of');
//  require('rxjs/add/operator/map');
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var rxjs_1 = require("rxjs");
var operators_1 = require("rxjs/operators");
var Class1 = /** @class */ (function () {
    function Class1() {
        this.name = 'MAX';
    }
    Class1.prototype.getName = function () {
        return this;
    };
    Class1.prototype.setName = function (name) {
        this.name = name;
    };
    return Class1;
}());
var Class2 = /** @class */ (function (_super) {
    __extends(Class2, _super);
    function Class2() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Class2.prototype.getName = function () {
        return this;
    };
    Class2.prototype.setName = function (name) {
        this.name = name;
    };
    return Class2;
}(Class1));
function hello(person) {
    return "Hello (Hi), " + person;
}
var Point = /** @class */ (function () {
    function Point() {
    }
    return Point;
}());
var point3d = { x: 1, y: 2, z: 3 };
var Person = /** @class */ (function () {
    function Person(name, surename) {
        this.name = name;
    }
    Person.prototype.getName = function () {
        return this.name;
    };
    Person.prototype.setName = function (name) {
        this.name = name;
    };
    return Person;
}());
var main = function () {
    var persons = [];
    persons.push(new Person("Andrzej", "Radzi"));
    persons.push(new Person("Izabela"));
    persons.push(new Person("Aleksandra"));
    persons.push(new Person("Mieczysław"));
    persons.push(new Person("Stanisława"));
    operators_1.first()(rxjs_1.of(1, 2, 3)).subscribe({
        next: function (response) { console.log(response); },
        error: function (err) { console.error('Error: ' + err); },
        complete: function () { console.log('Completed'); }
    });
    rxjs_1.of(persons).pipe(operators_1.map(function (person) { return person; })).subscribe(function (b) { return console.log(b); });
    // Create an Observable that will publish a value on an interval
    var secondsCounter = rxjs_1.interval(1000);
    var f;
    console.log(f);
    var userProperties; // "login" | "password"
    //userProperties = "login";
    var user;
    //user.login = '';
    var login; // string
    login = '23';
    console.log(userProperties);
    var Sex;
    (function (Sex) {
        Sex[Sex["Male"] = 0] = "Male";
        Sex[Sex["Female"] = 1] = "Female";
    })(Sex || (Sex = {}));
    ;
    // let ff: keyof Sex;
    // for (var p of ff)
    //     console.log(p);
    var tup = [1, "andrzej"];
    var user1; // declare tuple variable
    user1 = [1, "Steve", true, 20, "Admin"]; // initialize tuple variable
    var employee;
    employee = [[1, "Steve"], [2, "Bill"], [3, "Jeff"]];
    for (var _i = 0, employee_1 = employee; _i < employee_1.length; _i++) {
        var item = employee_1[_i];
        console.log(item);
    }
    for (var item in employee) {
        console.log(item);
    }
    //accessing to tuple
    employee[0];
    employee[1];
    // //adding new elements to tple
    employee.push([2, "Kamila"]);
    var code;
    code = 123; // OK
    code = "ABC"; // OK
    test1();
};
function getArray() {
    return ["andrzej", "marek", "radziszewski", "brzeziński"];
}
var test1 = function () {
    var _a, _b, _c, _d;
    var a, b;
    var a1, a2, rest;
    _a = [1, 2], a = _a[0], b = _a[1];
    _b = [b, a], a = _b[0], b = _b[1];
    _c = [-1, 1, 10, 20, 30], a1 = _c[0], a2 = _c[1], rest = _c.slice(2);
    console.log("Warto\u015B\u0107 a " + a);
    console.log("Warto\u015B\u0107 b " + b);
    console.log("Warto\u015B\u0107 rest " + rest);
    var _e = [5, 0], _f = _e[0], x = _f === void 0 ? 2 : _f, _g = _e[1], y = _g === void 0 ? 1000 : _g;
    console.log("Warto\u015B\u0107 x i y " + x + ", " + y);
    var _h = getArray(), r = _h.slice(3);
    console.log("Warto\u015B\u0107 " + r);
    var p1, p2;
    (_d = { p1: 1, p2: 2 }, p1 = _d.p1, p2 = _d.p2);
    console.log("Warto\u015B\u0107 p1 i p2 " + p1 + ", " + p2);
    var _j = { q1: 9000 }, _k = _j.q1, qq1 = _k === void 0 ? 100 : _k, _l = _j.q2, qq2 = _l === void 0 ? 500 : _l;
    console.log("Warto\u015B\u0107 qq1 i qq2 " + qq1 + ", " + qq2);
};
main();
