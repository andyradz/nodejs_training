// var Observable = require('rxjs/Observable').Observable;
// // // patch Observable with appropriate methods
//  require('rxjs/add/observable/of');
//  require('rxjs/add/operator/map');

import { interval, of } from 'rxjs';
import { first, map } from 'rxjs/operators';

class Class1 {

    name: string = 'MAX';

    getName(): Class1 {
        return this;
    }

    setName(name: string) {
        this.name = name;
    }
}

class Class2 extends Class1 {

    getName(): this {
        return this;
    }

    setName(name: string) {
        this.name = name;
    }
}


function hello(person: any): string {
    return "Hello (Hi), " + person;
}

class Point {
    x: number;
    y: number;
}

interface Point3d extends Point {
    z: number;
}

let point3d: Point3d = { x: 1, y: 2, z: 3 };

type common = Point & Point3d;

class Person {

    constructor(public name: string, surename?: string) { }

    public getName() {
        return this.name;
    }

    public setName(name: string) {
        this.name = name;
    }
}


let main = () => {

    const persons: Array<Person> = [] as Array<Person>;
    persons.push(new Person("Andrzej", "Radzi"));
    persons.push(new Person("Izabela"));
    persons.push(new Person("Aleksandra"));
    persons.push(new Person("Mieczysław"));
    persons.push(new Person("Stanisława"));

    first()(of(1, 2, 3)).subscribe({
        next(response) { console.log(response); },
        error(err) { console.error('Error: ' + err); },
        complete() { console.log('Completed'); }
    });
    of(persons).pipe(map((person) => person)).subscribe((b) => console.log(b));

    // Create an Observable that will publish a value on an interval
    const secondsCounter = interval(1000);
    // Subscribe to begin publishing values
    //const subscription = secondsCounter.subscribe(n => console.log(`It's been ${(n + 1) % 60} seconds since subscribing!`));
    //console.log(new Class2().setName("12"));

    type gg = keyof string;

    let f: gg;
    console.log(f);

    interface User {
        login: string;
        password: string;
    }

    let userProperties: keyof User; // "login" | "password"
    //userProperties = "login";

    let user: Readonly<User>;
    //user.login = '';
    let login: User['login']; // string
    login = '23';
    console.log(userProperties);

    enum Sex {
        Male,
        Female
    };

    // let ff: keyof Sex;

    // for (var p of ff)
    //     console.log(p);

    let tup: [number, string] = [1, "andrzej"];

    var user1: [number, string, boolean, number, string];// declare tuple variable
    user1 = [1, "Steve", true, 20, "Admin"];// initialize tuple variable

    var employee: [number, string][];
    employee = [[1, "Steve"], [2, "Bill"], [3, "Jeff"]];

    for (const item of employee) {
        console.log(item);
    }

    for (const item in employee) {
        console.log(item);
    }

    //accessing to tuple
    employee[0];
    employee[1];

    // //adding new elements to tple
    employee.push([2, "Kamila"]);

    let code: (string | number);
    code = 123;   // OK
    code = "ABC"; // OK
    //code = false; // Compiler Error


    type IsBoolean<T> = T extends boolean ? true : false;
    type t01 = IsBoolean<number>; // false
    type t02 = IsBoolean<string>; // false
    type t03 = IsBoolean<true>; // true

    type NonNullable<T> = T extends null | undefined
        ? never
        : T;

    type t04 = NonNullable<number>; // number
    type t05 = NonNullable<string | null>; // string
    type t06 = NonNullable<null | undefined>; // never   

    test1();
}

function getArray(): string[] {
    return ["andrzej", "marek", "radziszewski", "brzeziński"];
}

const test1 = () => {
    var a, b;
    var a1, a2, rest;
    [a, b] = [1, 2];
    [a, b] = [b, a];
    [a1, a2, ...rest] = [-1, 1, 10, 20, 30];
    console.log(`Wartość a ${a}`);
    console.log(`Wartość b ${b}`);
    console.log(`Wartość rest ${rest}`);

    var [x = 2, y = 1000] = [5, 0];
    console.log(`Wartość x i y ${x}, ${y}`);

    let [, , , ...r] = getArray();
    console.log(`Wartość ${r}`);

    var p1, p2;

    ({ p1, p2 } = { p1: 1, p2: 2 });
    console.log(`Wartość p1 i p2 ${p1}, ${p2}`);

    var { q1:qq1 = 100, q2:qq2 = 500 } = { q1: 9000 };
    console.log(`Wartość qq1 i qq2 ${qq1}, ${qq2}`);
};

main();