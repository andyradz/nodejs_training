import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MediaqueryComponent } from '../mediaquery/mediaquery.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    MediaqueryComponent],
  exports:[
    MediaqueryComponent
  ]    
})
export class ToolsModule { }
