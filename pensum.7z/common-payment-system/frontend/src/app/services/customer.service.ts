import { Injectable } from '@angular/core';
import { Observable, of, EMPTY, throwError } from 'rxjs';
import 'rxjs/add/observable/of';
import { map, tap, catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { IHero } from 'src/app/data/IHero';
// import { HttpClientInMemoryWebApiModule } from 'angular-in-memory-web-api';
// import { InMemoryDataService }  from './in-memory-data.service';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  private readonly heroesUrl = 'http://localhost:8080/heroes';  // URL to web api
  private httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Basic my-auth-token'
    })
  };

  constructor(private http: HttpClient) { }

  public getHeroes(): Observable<IHero[]> {
    return this.http.get<GetResponse>(this.heroesUrl)
      .pipe(
        map(response => response._embedded.heroes),
        tap(heroes => console.log(`fetched heroes` + heroes)),
        catchError(this.errorHandler)
      );
  }

  /* GET heroes whose name contains search term */
  searchHeroes(term: string): Observable<IHero[]> {

    if (!term.trim()) {
      // if not search term, return empty hero array.
      return of([]);
    }

    const url = `${this.heroesUrl}/search/name?contains=${term}`;
    return this.http.get<GetResponse>(url)
      .pipe(
        map(response => response._embedded.heroes),
        tap(_ => console.log(`found heroes matching "${term}"`)),
        catchError(this.errorHandler)
      );
  }

  /** PUT: update the hero on the server */
  updateHero(hero: IHero): Observable<any> {
    const url = `${this.heroesUrl}/${hero.id}`;

    return this.http
      .put(url, hero, this.httpOptions)
      .pipe(
        tap(_ => console.log(`updated hero id=${hero.id}`)),
        catchError(this.errorHandler));
  }

  errorHandler(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  }
}



export interface GetResponse {
  _embedded: {
    heroes: IHero[];
    _links: { self: { href: string } };
  };
}