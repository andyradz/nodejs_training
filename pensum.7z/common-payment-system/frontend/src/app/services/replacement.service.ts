import { Injectable } from '@angular/core';
import { Observable, from, of } from 'rxjs';
import { delay, map, tap, toArray } from 'rxjs/operators';
import { PageRequest, Page } from '../components/dashboard/page';
import { IReplacement, IReplacmentQuery } from '../data/IReplacement';

@Injectable({
  providedIn: 'root'
})
export class ReplacementService {

  /**
   * Creates an instance of replacement service.
   */
  public constructor() { }

  public page(request: PageRequest<IReplacement>, query: IReplacmentQuery): Observable<Page<IReplacement>> {

    let filteredReplacements: IReplacement[] = this.ELEMENT_DATA;
    let { search, lessonPerson } = query;

    if (search) {
      search = search.toLowerCase();
      filteredReplacements = filteredReplacements.filter(
        ({ lessonPerson }) =>
          lessonPerson.toLocaleLowerCase().includes(search)
      );
    }

    // if (lessonPerson) {

    // filteredReplacements = filteredReplacements.filter(
    //    ({ lessonDate }) =>
    //     //  lessonDate.getFullYear() === registration.getFullYear() &&
    //     //  lessonDate.getMonth() === registration.getMonth() &&
    //     //  lessonDate.getDate() === registration.getDate()
    //  //)
    //  ;}

    const start = request.page
      * request.size;
    const end = start
      + request.size;

    const pageUsers = filteredReplacements.slice(start, end);
    const page: Page<IReplacement> = {
      content: pageUsers,
      number: request.page,
      size: pageUsers.length,
      totalElements: filteredReplacements.length
    };

    return of(page);
  }

  private ELEMENT_DATA: IReplacement[] = [{
    id: 1,
    lessonDate: new Date('2020-11-16'),
    lessonPerson: 'Iwona Tolak',
    lessonClassNo: '1C',
    lessonHour: {
      lessonTimeStart: new Date('1990-01-01 08:55:00'),
      lessonTimeEnd: new Date('2020-01-01 09:40:00')
    },
    lessonRoomNo: 7
  },
  {
    id: 2,
    lessonDate: new Date('2020-11-16'),
    lessonPerson: 'Aleksandra Szoleska',
    lessonClassNo: '2A',
    lessonHour: {
      lessonTimeStart: new Date('1990-01-01 11:40:00'),
      lessonTimeEnd: new Date('2020-01-01 12:25:00')
    },
    lessonRoomNo: 4
  },
  {
    id: 3,
    lessonDate: new Date('2020-11-17'),
    lessonPerson: 'Iwona Tolak',
    lessonClassNo: '1C',
    lessonHour: {
      lessonTimeStart: new Date('1990-01-01 08:00:00'),
      lessonTimeEnd: new Date('2020-01-01 08:45:00')
    },
    lessonRoomNo: 3
  },
  {
    id: 4,
    lessonDate: new Date('2020-11-27'),
    lessonPerson: 'Iwona Tolak',
    lessonClassNo: '11C',
    lessonHour: {
      lessonTimeStart: new Date('1990-01-01 08:00:00'),
      lessonTimeEnd: new Date('2020-01-01 08:45:00')
    },
    lessonRoomNo: 55
  },
  {
    id: 5,
    lessonDate: new Date('2020-11-27'),
    lessonPerson: 'Iwona Tolak',
    lessonClassNo: '15C',
    lessonHour: {
      lessonTimeStart: new Date('1990-01-01 08:00:00'),
      lessonTimeEnd: new Date('2020-01-01 08:45:00')
    },
    lessonRoomNo: 55
  },
  {
    id: 6,
    lessonDate: new Date('2020-11-27'),
    lessonPerson: 'Iwona Mizgała',
    lessonClassNo: '115C',
    lessonHour: {
      lessonTimeStart: new Date('1990-01-01 08:00:00'),
      lessonTimeEnd: new Date('2020-01-01 08:45:00')
    },
    lessonRoomNo: 55
  }
];

  /**
   * Insert replacement entity to database
   */
  public insertReplacement = (replacement: IReplacement): void => {

    const replacements = [...this.ELEMENT_DATA];
    ++replacement.id;
    replacements.push(replacement);

    this.ELEMENT_DATA = [...replacements];
  }

  /**
   * Delete replacement entity from database
   */
  public deleteReplacement = (replacementId: number): void => {
    const { id } = this.ELEMENT_DATA
      .find(item => item.id !== replacementId);

    console.log(id);
    this.ELEMENT_DATA = [...this.ELEMENT_DATA.slice(0, replacementId),
    ...this.ELEMENT_DATA.slice(replacementId + 1)];
  }

  /**
   * Get replacements entities
   */
  public loadReplacements = (): Observable<IReplacement[]> => {
    
    return from<IReplacement[]>(this.ELEMENT_DATA)
      .pipe(
        delay(1),//generowanie sztucznego opóznienia                
        toArray()
      );
  }

  /**
   * Get replacements count
   */
  public dataLength = (): number => this.ELEMENT_DATA.length;

}
