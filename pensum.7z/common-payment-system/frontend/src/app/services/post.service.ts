import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { IPost, IPostQuery } from '../data/IPost';
import { PageRequest, Page } from '../components/dashboard/page';
import { User } from '../core/models/User';
import { delay } from 'rxjs/operators';
import { Guid } from 'guid-typescript';

type Category = {
	value: string,
	viewValue: string
}

@Injectable({
	providedIn: 'root'
})
export class PostService {

	public page(request: PageRequest<IPost>, query: IPostQuery): Observable<Page<IPost>> {
		// fake pagination, do your server request here instead
		let filteredUsers = this.ELEMENT_DATA;
		let { search, registration } = query;
		if (search) {
			search = search.toLowerCase();
			filteredUsers = filteredUsers.filter(
				({ title }) =>
					title.toLocaleLowerCase().includes(search)
			);
		}
		if (registration) {
			filteredUsers = filteredUsers.filter(
				({ date_posted }) =>
					date_posted.getFullYear() === registration.getFullYear() &&
					date_posted.getMonth() === registration.getMonth() &&
					date_posted.getDate() === registration.getDate()
			);
		}
		const start = request.page * request.size;
		const end = start + request.size;
		const pageUsers = filteredUsers.slice(start, end);
		const page = {
			content: pageUsers,
			number: request.page,
			size: pageUsers.length,
			totalElements: filteredUsers.length
		};
		return of(page).pipe(delay(1));
	}
	private categories: Category[] = [
		{ value: 'Web-Development', viewValue: 'Web Development' },
		{ value: 'Android-Development', viewValue: 'Android Development' },
		{ value: 'IOS-Development', viewValue: 'IOS Development' },
		{ value: 'IBM-AS400', viewValue: 'IBM-AS400 Development' },
		{ value: 'WiN API 32', viewValue: 'Windows API Development' }
	];

	private ELEMENT_DATA: IPost[] = [
		{ id: Guid.create(), checked: false, position: 1, title: 'Post One', category: 'Web Development', date_posted: new Date(), body: 'Body 1', percentage: 2, amount: 3999911162232211223230.09 },
		{ id: Guid.create(), checked: false, position: 2, title: 'Post Two', category: 'Android Development', date_posted: new Date(), body: 'Body 2', percentage: 2, amount: 777230.01 },
		{ id: Guid.create(), checked: false, position: 3, title: 'Post Three', category: 'IOS Development', date_posted: new Date(), body: 'Body 3', percentage: 2, amount: 2230.01 },
		{ id: Guid.create(), checked: false, position: 4, title: 'Post Four', category: 'Android Development', date_posted: new Date(), body: 'Body 4', percentage: 2, amount: 230.01 },
		{ id: Guid.create(), checked: false, position: 5, title: 'Post Five', category: 'IOS Development', date_posted: new Date(), body: 'Body 5', percentage: 2, amount: 230.01 },
		{ id: Guid.create(), checked: false, position: 6, title: 'Post Six', category: 'Web Development', date_posted: new Date(), body: 'Body 6', percentage: 2, amount: 220.01 },
		{ id: Guid.create(), checked: false, position: 7, title: 'Post Box', category: 'IBM Development', date_posted: new Date(), body: 'Body 9', percentage: 2, amount: 12120.01 },
		{ id: Guid.create(), checked: false, position: 8, title: 'MIx Box', category: 'IOS-Development', date_posted: new Date(), body: 'Body 7', percentage: 2.2, amount: 222232434242340.02 },
		{ id: Guid.create(), checked: false, position: 9, title: 'Ali Max', category: 'Windows-Development', date_posted: new Date(), body: 'Kolos 7', percentage: 2, amount: -110.02 }
	];

	constructor() {
	}

	public getData = (): Observable<IPost[]> => {
		return of<IPost[]>(this.ELEMENT_DATA);
	}

	public getCategories = () => {
		return this.categories;
	}

	public addPost = (data: IPost): void => {
		const list = [...this.ELEMENT_DATA];
		++data.position;
		list.push(data);
		// list.sort((a, b) => {
		// 	if (a.date_posted > b.date_posted) {
		// 		return -1;
		// 	}

		// 	if (a.date_posted < b.date_posted) {
		// 		return 1;
		// 	}

		// 	return 0;
		// });
		this.ELEMENT_DATA = [...list];
	}

	public deletePost = (index: number): void => {
		const { position } = this.ELEMENT_DATA.find(item => item.position !== index);
		console.log(position);
		this.ELEMENT_DATA = [...this.ELEMENT_DATA.slice(0, index), ...this.ELEMENT_DATA.slice(index + 1)];
	}

	public dataLength = (): number => {
		return this.ELEMENT_DATA.length;
	}
}
