type NOTADATE = '0001-01-01';

type NOTATIME = '00:00:00';

type NOTATIMESTAMP = '0001-01-01 00:00:00';

type LOGIC = true | false;

type YESNO = 'YESY' | 'NO';

type ODD = 1 | 3 | 5 | 7 | 9;

type EVEN = 0 | 2 | 4 | 6 | 8;