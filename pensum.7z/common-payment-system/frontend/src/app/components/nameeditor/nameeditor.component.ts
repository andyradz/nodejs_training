import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';

//https://angular.io/guide/reactive-forms

@Component({
  selector: 'app-name-editor',
  templateUrl: './nameeditor.component.html',
  styleUrls: ['./nameeditor.component.css']  
})
export class NameeditorComponent implements OnInit {

  public name = new FormControl('');

  constructor() { }

  ngOnInit(): void {
  }

}
