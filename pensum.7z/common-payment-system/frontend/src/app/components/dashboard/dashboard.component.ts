import { Component, OnInit, ViewChild } from '@angular/core';
import { PostService } from 'src/app/services/post.service';
import { Observable } from 'rxjs';
import { DataSource } from '@angular/cdk/table';
import { IPost, IPostQuery } from 'src/app/data/IPost';
import { MatDialog } from '@angular/material/dialog';
import { PostdialogComponent } from 'src/app/postdialog/postdialog.component';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { SelectionModel } from '@angular/cdk/collections';
import { MatSort } from '@angular/material/sort';
import { PaginatedDataSource } from './paginated-datasource';
import { ConfirmDialogModel, ConfirmDialogComponent } from 'src/app/shared/components/confirm-dialog/confirm-dialog.component';
import { IEmployee } from "../../data/IEmployee"


// https://stackblitz.com/angular/vjjjmankmle?file=app%2Ftable-expandable-rows-example.html

// https://blog.angular-university.io/angular-material-data-table/

// https://medium.com/@jeffgilliland/creating-a-dynamic-crud-service-in-angular-992229c9be56
// usługa CRUD

// https://angular-reactive-form-sobsoft.stackblitz.io/
// fajny interfejs

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: ['./dashboard.component.css'],
	animations: [
		trigger('detailExpand', [
			state('collapsed', style({ height: '0px', minHeight: '0' })),
			state('expanded', style({ height: '*' })),
			transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
		]),
	],
})
export class DashboardComponent implements OnInit {

	result: string = '';


	constructor(private postService: PostService, public dialog: MatDialog) {
		const employeeString = '{"department":"<anystring>","typeOfEmployee":"<anystring>","firstname":"<anystring>","lastname":"<anystring>","birthdate":"<anydate>","maxWorkHours":0,"username":"<anystring>","permissions":"<anystring>","lastUpdate":"<anydate>"}';

		let jsonObj: any = JSON.parse(employeeString); // string to generic object first
		let employee: IEmployee = jsonObj as IEmployee;
		console.log(employee);
	}

	@ViewChild(MatSort, { static: true }) sort: MatSort;

	allowMultiSelect = true;
	initialSelection: IPost[] = [];

	displayedColumns = ['checked', 'position', 'id', 'date_posted', 'time_posted', 'title', 'category', 'percentage', 'amount', 'actions'];
	data: PostDataSource = new PostDataSource(this.postService)
	//dataSource: MatTableDataSource<IPost> = new MatTableDataSource<IPost>(this.postService.ELEMENT_DATA);

	dataSource: PaginatedDataSource<IPost, IPostQuery>;

	expandedElement: PeriodicElement | null;
	selection = new SelectionModel<IPost>(this.allowMultiSelect, this.initialSelection);

	ngOnInit(): void {
		this.dataSource = new PaginatedDataSource<IPost, IPostQuery>(
			(request, query) => this.postService.page(request, query),
			{ property: 'title', order: 'desc' },
			{ search: '', registration: undefined },
			16
		);

	}

	/** Whether the number of selected elements matches the total number of rows. */
	isAllSelected() {
		//const numRows = this.dataSource.data.length;
		//return numSelected === numRows;
		return true;
	}

	/** Selects all rows if they are not all selected; otherwise clear selection. */
	masterToggle() {
		// this.isAllSelected() ?
		//this.selection.clear() :
		//this.dataSource.data.forEach(row => this.selection.select(row));
	}

	highlight(element: IPost): void {

		// fromEvent()

		element.highlighted = !element.highlighted;
	}

	openDialog(): void {

		const dialogRef = this.dialog.open(PostdialogComponent, {
			width: '1600px',
			height: '1200px',
			data: 'Dodaj rekord'
		});

		dialogRef.componentInstance.event.subscribe((result: { data: IPost; }) => {
			this.postService.addPost(result.data);
			this.dataSource.fetch(0);
			//this.dataSource.fetch()
			//this.dataSource.data.push(result.data);
			//this.dataSource.filter = '';
			//this.data = new PostDataSource(this.postService);
		});
	}

	deletePost(id: number): void {

		// if (this.auth.isAuthenticated()) {
		this.postService.deletePost(id);
		this.dataSource.fetch(0);
		// this.dataSource = new PostDataSource(this.postService);
		// } else {
		//  alert('Login in Before');
		// }
	}

	menuClosed(): void {
		if (this.selection.hasValue())
			this.selection.clear();
	}

	selectRow(row: IPost): void {
		if (this.selection.hasValue())
			this.selection.clear();

		this.selection.select(row);
	}

	selectPost(row: IPost): void {
		this.postService.deletePost(row.position);
		this.dataSource.fetch(0);
	}

	confirmDialog(post: IPost): void {
		const message = `Are you sure you want to do this? ${post.position} ${post.title}`;

		const dialogData = new ConfirmDialogModel("Confirm Action", message);

		const dialogRef = this.dialog.open(ConfirmDialogComponent, {
			maxWidth: "600px",
			data: dialogData
		});

		dialogRef.afterClosed().subscribe(dialogResult => {
			this.result = dialogResult;
			if (this.result)
				this.selectPost(post);
			else;
			this.selection.select(post);
		});
	}
}

export class PostDataSource extends DataSource<IPost> {
	constructor(private dataService: PostService) {
		super();
	}

	connect(): Observable<IPost[]> {
		return this.dataService.getData();
	}

	disconnect() {
	}
}

export interface PeriodicElement {
	name: string;
	position: number;
	weight: number;
	symbol: string;
	description: string;
}
