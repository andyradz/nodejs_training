import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main-footer',
  templateUrl: './mainfooter.component.html',
  styleUrls: ['./mainfooter.component.css']
})
export class MainFooterComponent implements OnInit {

  constructor() { }

  public ngOnInit = (): void => {
  }

  private onActivate = (event: any) => {
    window.scroll(0, 0);
    //or document.body.scrollTop = 0;
    //or document.querySelector('body').scrollTo(0,0) 
  }
}
