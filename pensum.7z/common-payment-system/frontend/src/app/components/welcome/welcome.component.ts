import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/core/models/User';
import { UserService } from 'src/app/core/services/userService';
import { first } from 'rxjs/operators';
import { StarRatingColor } from 'src/app/shared/components/rating/starRatingColor';

@Component({
	selector: 'app-welcome',
	templateUrl: './welcome.component.html',
	styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit {
	loading = false;
	users: User[]; // dataservice

	readonly elapsTime: number = 86400.99;

	rating = 0.5;
	starCount = 6;
	starColor: StarRatingColor = StarRatingColor.primary;
	starColorP: StarRatingColor = StarRatingColor.primary;
	starColorW: StarRatingColor = StarRatingColor.warn;

	constructor(private userService: UserService) { }

	ngOnInit() {
		this.loading = true;
		// this.userService
		// 	.getAll()
		// 	.pipe(first())
		// 	.subscribe((users: User[]) => {
		// 		this.loading = false;
		// 		this.users = users;
		// 	});
	}

	onRatingChanged(rating: number): void {
		this.rating = rating;
	}
}
