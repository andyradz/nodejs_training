import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MaterialModule } from './material/material.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { WelcomeComponent } from './components/welcome/welcome.component';
import { DataModule } from './data/data.module';
import { PostService } from './services/post.service';
import { CoreModule, FlexLayoutModule } from '@angular/flex-layout';
import { PostdialogComponent } from './postdialog/postdialog.component';
import { AuthService } from './services/auth.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RatingComponent } from './shared/components/rating/rating.component';
import { CountdownComponent } from './shared/components/countdown/countdown.component';
import { RegisterComponent } from './register/register.component';
import { ToolsModule } from './tools/tools.module';
import { StoreModule } from '@ngrx/store';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SanitizeHtmlPipe } from './shared/pipes/sanitize-html.pipe';
import { RequestCache } from './core/interceptors/request-cache';
import { CachingInterceptor } from './core/interceptors/caching-interceptor';
import { MainFooterComponent } from './components/mainfooter/mainfooter.component';
import { AnnoyingPopupDirectiveDirective } from './core/directive/annoying-popup-directive.directive'
import { CustomersModule } from './customers/customers.module';
import { PensumModule } from './pensum/pensum.module';
import { NameeditorComponent } from './components/nameeditor/nameeditor.component';
import { SelectComponent } from './components/select/select.component';
import { MatOption } from '@angular/material/core';
import { ReplacementService } from './services/replacement.service';

@NgModule({
	declarations: [
		AppComponent,
		WelcomeComponent,
		DashboardComponent,
		PostdialogComponent,
		LoginComponent,
		RatingComponent,
		CountdownComponent,
		RegisterComponent,
		MainFooterComponent,		
		AnnoyingPopupDirectiveDirective, 
		SelectComponent,
		NameeditorComponent							
	],
	imports: [
		BrowserModule,
		AppRoutingModule,
		BrowserAnimationsModule,
		MaterialModule,
		DataModule,
		FlexLayoutModule,
		FormsModule,
		ReactiveFormsModule,
		HttpClientModule,
		ToolsModule,
		FontAwesomeModule,
		CustomersModule,
		CoreModule,
		PensumModule,				
		StoreModule.forRoot({}, {})
	],
	providers: [
		PostService, AuthService, ReplacementService, 
				RequestCache, { provide: HTTP_INTERCEPTORS, useClass: CachingInterceptor, multi: true }
		// { provide: HTTP_INTERCEPTORS, useClass: BasicAuthInterceptor, multi: true },
		// { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
		// // provider used to create fake backend
		// fakeBackendProvider
	],
	exports: [
		AnnoyingPopupDirectiveDirective,NameeditorComponent
		// SanitizeHtmlPipe		
	],
	bootstrap: [AppComponent],
	entryComponents: [
		DashboardComponent
	],
})
export class AppModule { }
