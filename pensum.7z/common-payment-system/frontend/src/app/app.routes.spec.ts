import { AppRoutingModule } from './app-routing.module';

describe('App.Routes', () => {
  it('should create an instance', () => {
    expect(new AppRoutingModule()).toBeTruthy();
  });
});
