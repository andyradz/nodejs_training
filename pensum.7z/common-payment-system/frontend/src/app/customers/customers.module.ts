import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerManagmentComponent } from './customer-managment/customer-managment.component';


@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [CustomerManagmentComponent]
})
export class CustomersModule { }
