import { ElementRef } from '@angular/core';
import { AfterViewInit } from '@angular/core';
import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-customer-managment',
  templateUrl: './customer-managment.component.html',
  styleUrls: ['./customer-managment.component.css']
})
export class CustomerManagmentComponent implements OnInit, AfterViewInit {

  @ViewChild('buttons')
  private buttons: TemplateRef<any>;

  @ViewChild('b1')
  private b1: ElementRef;

  @ViewChild('b2')
  private b2: ElementRef;

  loginText = 'Login';
  signUpText = 'Sign Up';
  lessons = ['Lesson 1', 'Lesson 2', 'Lesson 3', 'Lesson 4', 'Lesson 5', 'Lesson 6', 'Lesson 7'];
  totalEstimate = 10;
  ctx = { estimate: this.totalEstimate, developer: "andrzej radziszewski" };

  login() {
    console.log('Login');
  }

  signUp() {
    console.log('Sign Up');
  }

  constructor() { }

  ngAfterViewInit(): void {
    console.log('Values on ngAfterViewInit():');
    console.log("buttons:", this.buttons);
    console.log("b1:", this.b1.nativeElement);
    console.log("b2:", this.b2.nativeElement);
  }

  public sortBy() {
    return this.lessons.sort((a, b) => a > b ? 1 : a === b ? 0 : -1);
  }

  ngOnInit(): void {
  }

}
