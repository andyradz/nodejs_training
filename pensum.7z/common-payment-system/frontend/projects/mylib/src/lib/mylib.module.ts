import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { MylibComponent } from '../public-api';

@NgModule({
  declarations: [MylibComponent],
  imports: [CommonModule, HttpClientModule],
  exports: [MylibComponent]
})
export class MylibModule { }
