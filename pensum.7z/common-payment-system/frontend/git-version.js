const chidProcess = require('child_process');
const { writeFileSync } = require('fs');

const {version} = require('./package.json');

const appVersion = chidProcess.execSync("git describe --abbrev=0 --tags").toString().trim();
const appLongSHA = chidProcess.execSync("git rev-parse HEAD").toString().trim();
const appShortSHA = chidProcess.execSync("git rev-parse --short HEAD").toString().trim();
const appBranch = chidProcess.execSync('git rev-parse --abbrev-ref HEAD').toString().trim();
const appAuthor = chidProcess.execSync("git log -1 --pretty=format:'%an'").toString().trim();
const appCommitTime = chidProcess.execSync("git log -1 --pretty=format:'%cd'").toString().trim();
const appCommitMessage = chidProcess.execSync("git log -1 --pretty=%B").toString().trim();
const appTotalCommitCount = chidProcess.execSync("git rev-list --count HEAD").toString().trim();

const versionInfo = {
    appVersion: appVersion,
    appBuild: version,
    appShortSHA: appShortSHA,
    appLongSHA : appLongSHA,
    appBranch: appBranch,
    appAuthor: appAuthor,
    appCommitTime: appCommitTime,
    appCommitMessage: appCommitMessage,
    appCommitNumber: appTotalCommitCount
}

const versionInfoJson = JSON.stringify(versionInfo, null, 2);

writeFileSync('git-version.json', versionInfoJson);