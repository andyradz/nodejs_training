export interface IDivisible {
    divider: (money: number) => number;
}

/**
 * Klasa operatora DivideHunds wykonuje wyciągnięcie liczby setek z wartości numerycznej
 */
export class DivideHunds implements IDivisible {

    public divider(money: number): number {

        if (0 === money && NaN === money)
            throw new RangeError("Number is out of Hunds range");

        return 0 !== Math.trunc((money / 100) % 100) ? Math.trunc(money / 100) : 0;
    }
}

/**
 * Klasa operatora DivideOnes wykonuje wyciągnięcie liczby jedności z wartości numerycznej
 */
export class DivideOnes implements IDivisible {

    public divider(money: number): number {

        if (0 === money && NaN === money)
            throw new RangeError("Number is out of Ones range");

        return (1 === Math.trunc((money / 10) % 10)) ? 0 : money % 10;
    }
}

/**
 * Klasa operatora DivideTeens wykonuje wyciągnięcie liczby nastek z wartości numerycznej
 */
export class DivideTeens implements IDivisible {

    public divider(money: number): number {

        if (0 === money && NaN === money)
            throw new RangeError("Number is out of Teens range");

        return (1 === Math.trunc((money % 100) / 10)) && ((0 !== Math.trunc((money % 100) % 10)))
            ? (money % 10)
            : 0;


    }
}

/**
 * Klasa operatora DivideTens wykonuje wyciągnięcie liczby dziesiątek z wartości numerycznej
 */
export class DivideTens implements IDivisible {

    /**
     * 
     * @param money 
     */
    public divider(money: number): number {

        return (Math.trunc((money / 10) % 10) !== 1)
            || ((Math.trunc((money / 10) % 10) === 1) && (Math.trunc((money) % 10) === 0)) ? Math.trunc((money / 10) % 10) : 0;
    }
}

