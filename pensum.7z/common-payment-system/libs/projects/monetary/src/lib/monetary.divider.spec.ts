import { TestBed } from '@angular/core/testing';
import { DivideOnes } from 'dist/monetary/lib/divider';
import { DivideHunds, DivideTeens, DivideTens, IDivisible } from './divider';
import { MonetaryComponent } from './monetary.component';

https://medium.com/swlh/angular-unit-testing-jasmine-karma-step-by-step-e3376d110ab4

describe('dividing tests', () => {
    var divider: IDivisible;

    beforeEach(() => {
         TestBed.configureTestingModule({
            declarations: [
                MonetaryComponent
                //DivideHunds
            ]
        }).compileComponents();
        divider = new DivideTens();
    });

    afterAll(() => {

    });
   
    it("test dividing onse", () =>{
        const divider: IDivisible = new DivideOnes();
        const value: number = divider.divider(251);
        expect(value).toEqual(1);
    })

    it("test dividing tens", () =>{
        const divider: IDivisible = new DivideTens();
        const value: number = divider.divider(251);
        expect(value).toEqual(5);
    })

    it("test dividing teens", () =>{
        const divider: IDivisible = new DivideTeens();
        const value: number = divider.divider(217);
        expect(value).toEqual(7);
    })

    it('test dividing hunds', () => {
        const divider: IDivisible = new DivideHunds();
        const value: number = divider.divider(200);
        expect(value).toEqual(2);
    });

});
