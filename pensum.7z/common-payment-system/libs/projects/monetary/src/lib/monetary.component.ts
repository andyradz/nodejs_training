import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-monetary',
  template: `
    <p>
      monetary works!
    </p>
  `,
  styles: []
})
export class MonetaryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
