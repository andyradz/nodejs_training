import { NgModule } from '@angular/core';
import { DivideHunds, DivideOnes, DivideTeens, DivideTens } from './divider';
import { MonetaryComponent } from './monetary.component';

@NgModule({
  declarations: [
    MonetaryComponent
  ],
  imports: [
  ],
  exports: [MonetaryComponent],
  providers: [
  ]
})
export class MonetaryModule { }
